<script setup lang="ts">
import { RouterView } from 'vue-router';
</script>

<template>
  <RouterView />
</template>

<style scoped>
body {
  font-family: Arial, Helvetica, sans-serif;
}
</style>
