export class DeleteCommand {
    constructor(public readonly id: number) {}
}