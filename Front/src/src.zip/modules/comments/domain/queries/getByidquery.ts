export class GetByIdQuery{
    constructor(public readonly id: number) {}
}