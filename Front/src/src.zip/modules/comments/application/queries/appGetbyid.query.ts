export class AppGetByIdQuery {
    constructor(public readonly id: number) { }
}