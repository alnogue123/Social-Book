export class AppDeleteCommand {
    constructor(public readonly id: number) {}
}