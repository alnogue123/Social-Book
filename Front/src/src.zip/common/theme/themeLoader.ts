(function () {
  localStorage.getItem("theme") === "dark" && document.documentElement.classList.add("dark-mode");
})();
