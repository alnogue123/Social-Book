export interface ListType{
    value: string;
    id: number;
}