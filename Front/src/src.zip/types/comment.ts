export interface Comment {
    noteID: number
    commentID: number
    userID : number
    description: string
}