<script setup lang="ts"></script>
<template>
    notas borradas
</template>
<style scoped src="/src/assets/Styles/layouts/DeletedNoted.css"></style>