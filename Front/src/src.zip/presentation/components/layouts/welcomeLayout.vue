<script setup></script>
<template>
    <div class="minicontainer">
        <p class="title">Social Book</p>
        <i class="pi pi-book book"></i>
        <p class="Slogan toTranslate">Share your notes, ideas, and more!</p>
    </div>
</template>

<style scoped src="/src/assets/Styles/layouts/WelcomeLayout.css"></style>