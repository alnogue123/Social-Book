export interface Pokemon{
    name:string,
    image: string,
    abilities: string,
    types: string,
}