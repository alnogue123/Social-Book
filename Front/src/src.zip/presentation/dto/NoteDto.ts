export interface Note{
    userID : number
    id: number
    title: string
    body: string
    isPublic: boolean
}